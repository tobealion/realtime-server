﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Management.Automation;
using System.Management.Automation.Runspaces;

namespace BackupTool
{
    class Program
    {
        public static string base64_script = "ZmlsdGVyIFByb2Nlc3NXTUlKb2IgDQp7IA0KICAgIHBhcmFtIA0KICAgICggDQogICAgICAgIFtXTUldJFdtaUNsYXNzID0gJG51bGwsDQogICAgICAgIFtzdHJpbmddJE1ldGhvZE5hbWUgPSAkbnVsbA0KICAgICkNCgkkZXJyb3JDb2RlID0gMA0KICAgICRyZXR1cm5PYmplY3QgPSAkXw0KDQogICAgaWYgKCRfLlJldHVyblZhbHVlIC1lcSA0MDk2KSANCiAgICB7IA0KICAgICAgICAkSm9iID0gW1dNSV0kXy5Kb2IgDQogICAgICAgICRyZXR1cm5PYmplY3QgPSAkSm9iDQoNCiAgICAgICAgd2hpbGUgKCRKb2IuSm9iU3RhdGUgLWVxIDQpIA0KICAgICAgICB7IA0KICAgICAgICAgICAgV3JpdGUtUHJvZ3Jlc3MgLUFjdGl2aXR5ICRKb2IuQ2FwdGlvbiAtU3RhdHVzICgkSm9iLkpvYlN0YXR1cyArICIgLSAiICsgJEpvYi5QZXJjZW50Q29tcGxldGUgKyAiJSIpIC1QZXJjZW50Q29tcGxldGUgJEpvYi5QZXJjZW50Q29tcGxldGUNCiAgICAgICAgICAgIFN0YXJ0LVNsZWVwIC1zZWNvbmRzIDENCiAgICAgICAgICAgICRKb2IuUFNCYXNlLkdldCgpDQogICAgICAgIH0gDQogICAgICAgIGlmICgkSm9iLkpvYlN0YXRlIC1uZSA3KSANCiAgICAgICAgeyANCgkJCWlmICgkSm9iLkVycm9yRGVzY3JpcHRpb24gLW5lICIiKQ0KCQkJew0KICAgICAgICAgICAgCVdyaXRlLUVycm9yICRKb2IuRXJyb3JEZXNjcmlwdGlvbiANCiAgICAgICAgICAgIAlUaHJvdyAkSm9iLkVycm9yRGVzY3JpcHRpb24gDQoJCQl9DQoJCQllbHNlDQoJCQl7DQoJCQkJJGVycm9yQ29kZSA9ICRKb2IuRXJyb3JDb2RlDQoJCQl9DQogICAgICAgIH0gDQogICAgICAgIFdyaXRlLVByb2dyZXNzIC1BY3Rpdml0eSAkSm9iLkNhcHRpb24gLVN0YXR1cyAkSm9iLkpvYlN0YXR1cyAtUGVyY2VudENvbXBsZXRlIDEwMCAtQ29tcGxldGVkOiR0cnVlDQogICAgICAgIA0KICAgIH0NCgllbHNlaWYoJF8uUmV0dXJuVmFsdWUgLW5lIDApDQoJew0KCQkkZXJyb3JDb2RlID0gJF8uUmV0dXJuVmFsdWUNCgl9DQoJDQoJaWYgKCRlcnJvckNvZGUgLW5lIDApIA0KICAgIHsgDQogICAgICAgIFdyaXRlLUVycm9yICJIeXBlci1WIFdNSSBKb2IgRmFpbGVkISIgDQogICAgICAgIGlmICgkV21pQ2xhc3MgLWFuZCAkTWV0aG9kTmFtZSkNCiAgICAgICAgew0KICAgICAgICAgICAgJHBzV21pQ2xhc3MgPSBbV21pQ2xhc3NdKCJcXCIgKyAkV21pQ2xhc3MuX19TRVJWRVIgKyAiXCIgKyAkV21pQ2xhc3MuX19OQU1FU1BBQ0UgKyAiOiIgKyAkV21pQ2xhc3MuX19DTEFTUykNCiAgICAgICAgICAgICRwc1dtaUNsYXNzLlBTQmFzZS5PcHRpb25zLlVzZUFtZW5kZWRRdWFsaWZpZXJzID0gJFRSVUUNCiAgICAgICAgICAgICRNZXRob2RRdWFsaWZpZXJWYWx1ZXMgPSAoJHBzV21pQ2xhc3MuUFNCYXNlLk1ldGhvZHNbJE1ldGhvZE5hbWVdLlF1YWxpZmllcnMpWyJWYWx1ZXMiXQ0KICAgICAgICAgICAgJGluZGV4T2ZFcnJvciA9IFtTeXN0ZW0uQXJyYXldOjpJbmRleE9mKCgkcHNXbWlDbGFzcy5QU0Jhc2UuTWV0aG9kc1skTWV0aG9kTmFtZV0uUXVhbGlmaWVycylbIlZhbHVlTWFwIl0uVmFsdWUsIFtzdHJpbmddJGVycm9yQ29kZSkNCiAgICAgICAgICAgIGlmICgoJGluZGV4T2ZFcnJvciAtbmUgIi0xIikgLWFuZCAkTWV0aG9kUXVhbGlmaWVyVmFsdWVzKQ0KICAgICAgICAgICAgew0KICAgICAgICAgICAgICAgIFRocm93ICJSZXR1cm5Db2RlOiAiLCAkZXJyb3JDb2RlLCAiIEVycm9yTWVzc2FnZTogJyIsICRNZXRob2RRdWFsaWZpZXJWYWx1ZXMuVmFsdWVbJGluZGV4T2ZFcnJvcl0sICInIC0gd2hlbiBjYWxsaW5nICRNZXRob2ROYW1lIg0KICAgICAgICAgICAgfQ0KICAgICAgICAgICAgZWxzZQ0KICAgICAgICAgICAgew0KICAgICAgICAgICAgICAgIFRocm93ICJSZXR1cm5Db2RlOiAiLCAkZXJyb3JDb2RlLCAiIEVycm9yTWVzc2FnZTogJ01lc3NhZ2VOb3RGb3VuZCcgLSB3aGVuIGNhbGxpbmcgJE1ldGhvZE5hbWUiDQogICAgICAgICAgICB9DQogICAgICAgIH0NCiAgICAgICAgZWxzZQ0KICAgICAgICB7DQogICAgICAgICAgICBUaHJvdyAiUmV0dXJuQ29kZTogIiwgJGVycm9yQ29kZSwgIldoZW4gY2FsbGluZyAkTWV0aG9kTmFtZSAtIGZvciByaWNoIGVycm9yIG1lc3NhZ2VzIHByb3ZpZGUgY2xhc3NwYXRoIGFuZCBtZXRob2QgbmFtZS4iDQogICAgICAgIH0NCiAgICB9IA0KCXJldHVybiAkcmV0dXJuT2JqZWN0DQp9DQoNCg0KZnVuY3Rpb24gQ29udmVydC1WbUJhY2t1cENoZWNrcG9pbnQNCnsNCiAgICBQYXJhbSgNCiAgICAgIFtQYXJhbWV0ZXIoTWFuZGF0b3J5PSRUcnVlKV0NCiAgICAgIFtTeXN0ZW0uTWFuYWdlbWVudC5NYW5hZ2VtZW50T2JqZWN0XSRCYWNrdXBDaGVja3BvaW50ID0gJG51bGwNCiAgICApDQoNCiAgICAjIFJldHJpZXZlIGFuIGluc3RhbmNlIG9mIHRoZSBzbmFwc2hvdCBtYW5hZ2VtZW50IHNlcnZpY2UNCiAgICAkTXN2bV9WaXJ0dWFsU3lzdGVtU25hcHNob3RTZXJ2aWNlID0gR2V0LVdtaU9iamVjdCAtTmFtZXNwYWNlIHJvb3RcdmlydHVhbGl6YXRpb25cdjIgLUNsYXNzIE1zdm1fVmlydHVhbFN5c3RlbVNuYXBzaG90U2VydmljZQ0KDQogICAgIyBDb252ZXJ0IHRoZSBzbmFwc2hvdCB0byBhIHJlZmVyZW5jZSBwb2ludCwgdGhpcyBmdW5jdGlvbiByZXR1cm5zIGEgam9iIG9iamVjdC4NCiAgICAkam9iID0gJE1zdm1fVmlydHVhbFN5c3RlbVNuYXBzaG90U2VydmljZS5Db252ZXJ0VG9SZWZlcmVuY2VQb2ludCgkQmFja3VwQ2hlY2twb2ludCkNCg0KICAgICMgV2FpdCBmb3IgdGhlIGpvYiB0byBjb21wbGV0ZS4NCiAgICAoJGpvYiB8IFByb2Nlc3NXTUlKb2IgLVdtaUNsYXNzICRNc3ZtX1ZpcnR1YWxTeXN0ZW1TbmFwc2hvdFNlcnZpY2UgLU1ldGhvZE5hbWUgIkNvbnZlcnRUb1JlZmVyZW5jZVBvaW50IikgfCBPdXQtTnVsbA0KDQogICAgIyBUaGUgbmV3IHJlZmVyZW5jZSBwb2ludCBvYmplY3QgaXMgcmVsYXRlZCB0byB0aGUgam9iLCBHZXRSZWxlYXRlZCANCiAgICAjICAgYWx3YXlzIHJldHVybnMgYW4gYXJyYXkgaW4gdGhpcyBjYXNlIHRoZXJlIGlzIG9ubHkgb25lIG1lbWJlcg0KICAgICRyZWZQb2ludCA9ICgoW1dNSV0kam9iLkpvYikuR2V0UmVsYXRlZCgiTXN2bV9WaXJ0dWFsU3lzdGVtUmVmZXJlbmNlUG9pbnQiKSB8ICUgeyRffSkNCg0KICAgICMgUmV0dXJuIHRoZSByZWZlcmVuY2UgcG9pbnQgb2JqZWN0DQogICAgcmV0dXJuICRyZWZQb2ludA0KfQ0KDQpmdW5jdGlvbiBFeHBvcnQtVk1CYWNrdXBDaGVja3BvaW50DQp7DQogICAgUGFyYW0oDQogICAgICBbUGFyYW1ldGVyKE1hbmRhdG9yeT0kVHJ1ZSldDQogICAgICBbc3RyaW5nXSRWbU5hbWUgPSBbU3RyaW5nXTo6RW1wdHksDQoNCiAgICAgIFtQYXJhbWV0ZXIoTWFuZGF0b3J5PSRUcnVlKV0NCiAgICAgIFtzdHJpbmddJERlc3RpbmF0aW9uUGF0aCA9IFtTdHJpbmddOjpFbXB0eSwNCg0KICAgICAgW1BhcmFtZXRlcihNYW5kYXRvcnk9JFRydWUpXQ0KICAgICAgW1N5c3RlbS5NYW5hZ2VtZW50Lk1hbmFnZW1lbnRPYmplY3RdJEJhY2t1cENoZWNrcG9pbnQgPSAkbnVsbCwNCg0KICAgICAgW1N5c3RlbS5NYW5hZ2VtZW50Lk1hbmFnZW1lbnRPYmplY3RdJFJlZmVyZW5jZVBvaW50ID0gJG51bGwsDQoNCiAgICAgIFtib29sXSRub1dhaXQgPSAkZmFsc2UNCiAgICApDQoNCiAgICAjIFJldHJpZXZlIGFuIGluc3RhbmNlIG9mIHRoZSB2aXJ0dWFsIG1hY2hpbmUgbWFuYWdlbWVudCBzZXJ2aWNlDQogICAgJE1zdm1fVmlydHVhbFN5c3RlbU1hbmFnZW1lbnRTZXJ2aWNlID0gR2V0LVdtaU9iamVjdCAtTmFtZXNwYWNlIHJvb3RcdmlydHVhbGl6YXRpb25cdjIgLUNsYXNzIE1zdm1fVmlydHVhbFN5c3RlbU1hbmFnZW1lbnRTZXJ2aWNlDQoNCiAgICAjIFJldHJpZXZlIGFuIGluc3RhbmNlIG9mIHRoZSB2aXJ0dWFsIG1hY2hpbmUgY29tcHV0ZXIgc3lzdGVtIHRoYXQgd2lsbCBiZSBzbmFwc2hvdGVkDQogICAgJE1zdm1fQ29tcHV0ZXJTeXN0ZW0gPSBHZXQtV21pT2JqZWN0IC1OYW1lc3BhY2Ugcm9vdFx2aXJ0dWFsaXphdGlvblx2MiAtQ2xhc3MgTXN2bV9Db21wdXRlclN5c3RlbSAtRmlsdGVyICJFbGVtZW50TmFtZT0nJHZtTmFtZSciDQoNCiAgICAjIFJldHJpZXZlIGFuIGluc3RhbmNlIG9mIHRoZSBFeHBvcnQgU2V0dGluZyBEYXRhIENsYXNzICh0aGlzIGlzIHVzZWQgdG8gaW5mb3JtIHRoZSBleHBvcnQgb3BlcmF0aW9uKQ0KICAgICMgIEdldFJlbGVhdGVkIGFsd2F5cyByZXR1cm5zIGFuIGFycmF5IGluIHRoaXMgY2FzZSB0aGVyZSBpcyBvbmx5IG9uZSBtZW1iZXINCiAgICAkTXN2bV9WaXJ0dWFsU3lzdGVtRXhwb3J0U2V0dGluZ0RhdGEgPSAoJE1zdm1fQ29tcHV0ZXJTeXN0ZW0uR2V0UmVsYXRlZCgiTXN2bV9WaXJ0dWFsU3lzdGVtRXhwb3J0U2V0dGluZ0RhdGEiLCJNc3ZtX1N5c3RlbUV4cG9ydFNldHRpbmdEYXRhIiwkbnVsbCwkbnVsbCwgJG51bGwsICRudWxsLCAkZmFsc2UsICRudWxsKSB8ICUgeyRffSkNCg0KICAgICMgU3BlY2lmeSB0aGUgZXhwb3J0IG9wdGlvbnMNCiAgICAgICAgIyAgIENvcHlTbmFwc2hvdENvbmZpZ3VyYXRpb24NCiAgICAgICAgIyAgICAgIDA6IEV4cG9ydEFsbFNuYXBzaG90cyAtIEFsbCBzbmFwc2hvdHMgd2lsbCBiZSBleHBvcnRlZCB3aXRoIHRoZSBWTS4NCiAgICAgICAgIyAgICAgIDE6IEV4cG9ydE5vU25hcHNob3RzIC0gTm8gc25hcHNob3RzIHdpbGwgYmUgZXhwb3J0ZWQgd2l0aCB0aGUgVk0uDQogICAgICAgICMgICAgICAyOiBFeHBvcnRPbmVTbmFwc2hvdCAtIFRoZSBzbmFwc2hvdCBpZGVudGlmaWVkIGJ5IHRoZSBTbmFwc2hvdFZpcnR1YWxTeXN0ZW0gcHJvcGVydHkgd2lsbCBiZSBleHBvcnRlZCB3aXRoIHRoZSBWTS4NCiAgICAgICAgIyAgICAgIDM6IEV4cG9ydE9uZVNuYXBzaG90VXNlVm1JZCAgLSBUaGUgc25hcHNob3QgaWRlbnRpZmllZCBieSB0aGUgU25hcHNob3RWaXJ0dWFsU3lzdGVtIHByb3BlcnR5IHdpbGwgYmUgZXhwb3J0ZWQgd2l0aCB0aGUgVk0uIFVzaW5nIHRoZSBWTXMgSUQuDQogICAgICAgICRNc3ZtX1ZpcnR1YWxTeXN0ZW1FeHBvcnRTZXR0aW5nRGF0YS5Db3B5U25hcHNob3RDb25maWd1cmF0aW9uID0gMw0KDQogICAgICAgICMgICBDb3B5Vm1SdW50aW1lSW5mb3JtYXRpb24NCiAgICAgICAgIyAgICAgIEluZGljYXRlcyB3aGV0aGVyIHRoZSBWTSBydW50aW1lIGluZm9ybWF0aW9uIHdpbGwgYmUgY29waWVkIHdoZW4gdGhlIFZNIGlzIGV4cG9ydGVkLiAoaS5lLiBzYXZlZCBzdGF0ZSkNCiAgICAgICAgJE1zdm1fVmlydHVhbFN5c3RlbUV4cG9ydFNldHRpbmdEYXRhLkNvcHlWbVJ1bnRpbWVJbmZvcm1hdGlvbiA9ICRmYWxzZQ0KDQogICAgICAgICMgICBDb3B5Vm1TdG9yYWdlDQogICAgICAgICMgICAgICBJbmRpY2F0ZXMgd2hldGhlciB0aGUgVk0gc3RvcmFnZSB3aWxsIGJlIGNvcGllZCB3aGVuIHRoZSBWTSBpcyBleHBvcnRlZC4gIChpLmUuIFZIRHMvVkhEeCBmaWxlcykNCiAgICAgICAgJE1zdm1fVmlydHVhbFN5c3RlbUV4cG9ydFNldHRpbmdEYXRhLkNvcHlWbVN0b3JhZ2UgPSAkdHJ1ZQ0KDQogICAgICAgICMgICBDcmVhdGVWbUV4cG9ydFN1YmRpcmVjdG9yeQ0KICAgICAgICAjICAgICAgSW5kaWNhdGVzIHdoZXRoZXIgYSBzdWJkaXJlY3Rvcnkgd2l0aCB0aGUgbmFtZSBvZiB0aGUgVk0gd2lsbCBiZSBjcmVhdGVkIHdoZW4gdGhlIFZNIGlzIGV4cG9ydGVkLg0KICAgICAgICAkTXN2bV9WaXJ0dWFsU3lzdGVtRXhwb3J0U2V0dGluZ0RhdGEuQ3JlYXRlVm1FeHBvcnRTdWJkaXJlY3RvcnkgPSAkZmFsc2UNCg0KICAgICAgICAjICAgU25hcHNob3RWaXJ0dWFsU3lzdGVtDQogICAgICAgICMgICAgICBQYXRoIHRvIGEgTXN2bV9WaXJ0dWFsU3lzdGVtU2V0dGluZ0RhdGEgaW5zdGFuY2UgdGhhdCByZXByZXNlbnRzIHRoZSBzbmFwc2hvdCB0byBiZSBleHBvcnRlZCB3aXRoIHRoZSBWTS4NCiAgICAgICAgJE1zdm1fVmlydHVhbFN5c3RlbUV4cG9ydFNldHRpbmdEYXRhLlNuYXBzaG90VmlydHVhbFN5c3RlbSA9ICRCYWNrdXBDaGVja3BvaW50DQoNCiAgICAgICAgIyAgIERpZmZlcmVudGlhbEJhc2UNCiAgICAgICAgIyAgICAgIEJhc2UgZm9yIGRpZmZlcmVudGlhbCBleHBvcnQuIFRoaXMgaXMgZWl0aGVyIHBhdGggdG8gYSBNc3ZtX1ZpcnR1YWxTeXN0ZW1SZWZlcmVuY2VQb2ludCBpbnN0YW5jZSB0aGF0DQogICAgICAgICMgICAgICAgICByZXByZXNlbnRzIHRoZSByZWZlcmVuY2UgcG9pbnQgb3IgcGF0aCB0byBhIE1zdm1fVmlydHVhbFN5c3RlbVNldHRpbmdEYXRhIGluc3RhbmNlIHRoYXQNCiAgICAgICAgIyAgICAgICAgIHJlcHJlc2VudHMgdGhlIHNuYXBzaG90IHRvIGJlIHVzZWQgYXMgYSBiYXNlIGZvciBkaWZmZXJlbnRpYWwgZXhwb3J0LiBJZiB0aGUgQ29weVNuYXBzaG90Q29uZmlndXJhdGlvbg0KICAgICAgICAjICAgICAgICAgcHJvcGVydHkgaXMgbm90IHNldCB0byAzKEV4cG9ydE9uZVNuYXBzaG90VXNlVm1JZCksIHRoaXMgcHJvcGVydHkgaXMgaWdub3JlZC4iDQogICAgICAgICRNc3ZtX1ZpcnR1YWxTeXN0ZW1FeHBvcnRTZXR0aW5nRGF0YS5EaWZmZXJlbnRpYWxCYWNrdXBCYXNlID0gJFJlZmVyZW5jZVBvaW50DQoNCiAgICAgICAgIyAgIFN0b3JhZ2VDb25maWd1cmF0aW9uDQogICAgICAgICMgICAgICBJbmRpY2F0ZXMgd2hhdCBzaG91bGQgYmUgdGhlIFZIRCBwYXRoIGluIHRoZSBleHBvcnRlZCBjb25maWd1cmF0aW9uLg0KICAgICAgICAjICAgICAgICAwOiBTdG9yYWdlQ29uZmlndXJhdGlvbkN1cnJlbnQgLSBUaGUgZXhwb3J0ZWQgY29uZmlndXJhdGlvbiB3b3VsZCBwb2ludCB0byB0aGUgY3VycmVudCBWSEQuDQogICAgICAgICMgICAgICAgIDE6IFN0b3JhZ2VDb25maWd1cmF0aW9uQmFzZVZoZCAtIFRoZSBleHBvcnRlZCBjb25maWd1cmF0aW9uIHdvdWxkIHBvaW50IHRvIHRoZSBiYXNlIFZIRC4NCiAgICAgICAgIyRNc3ZtX1ZpcnR1YWxTeXN0ZW1FeHBvcnRTZXR0aW5nRGF0YS5TdG9yYWdlQ29uZmlndXJhdGlvbiA9IDENCg0KICAgICNFeHBvcnQgdGhlIHZpcnR1YWwgbWFjaGluZSBzbmFwc2hvdCwgdGhpcyBtZXRob2QgcmV0dXJucyBhIGpvYiBvYmplY3QuDQogICAgJGpvYiA9ICRNc3ZtX1ZpcnR1YWxTeXN0ZW1NYW5hZ2VtZW50U2VydmljZS5FeHBvcnRTeXN0ZW1EZWZpbml0aW9uKCRNc3ZtX0NvbXB1dGVyU3lzdGVtLCAkRGVzdGluYXRpb25QYXRoLCAkTXN2bV9WaXJ0dWFsU3lzdGVtRXhwb3J0U2V0dGluZ0RhdGEuR2V0VGV4dCgxKSkNCg0KICAgIGlmICghJG5vV2FpdCkNCiAgICB7DQogICAgICAgICgkam9iIHwgUHJvY2Vzc1dNSUpvYiAtV21pQ2xhc3MgJE1zdm1fVmlydHVhbFN5c3RlbU1hbmFnZW1lbnRTZXJ2aWNlIC1NZXRob2ROYW1lICJFeHBvcnRTeXN0ZW1EZWZpbml0aW9uIikgfCBPdXQtTnVsbA0KICAgIH0NCn0NCg0KZnVuY3Rpb24gR2V0LVZtQmFja3VwQ2hlY2twb2ludHMNCnsNCiAgICBQYXJhbSgNCiAgICAgIFtQYXJhbWV0ZXIoTWFuZGF0b3J5PSRUcnVlKV0NCiAgICAgIFtzdHJpbmddJFZtTmFtZSA9IFtTdHJpbmddOjpFbXB0eQ0KICAgICkNCg0KICAgICMgUmV0cmlldmUgYW4gaW5zdGFuY2Ugb2YgdGhlIHZpcnR1YWwgbWFjaGluZSBjb21wdXRlciBzeXN0ZW0gdGhhdCBjb250YWlucyByZWNvdmVyeSBjaGVja3BvaW50cw0KICAgICRNc3ZtX0NvbXB1dGVyU3lzdGVtID0gR2V0LVdtaU9iamVjdCAtTmFtZXNwYWNlIHJvb3RcdmlydHVhbGl6YXRpb25cdjIgLUNsYXNzIE1zdm1fQ29tcHV0ZXJTeXN0ZW0gLUZpbHRlciAiRWxlbWVudE5hbWU9JyRWbU5hbWUnIg0KDQogICAgIyBSZXRyaWV2ZSBhbGwgc25hcHNob3QgYXNzb2NpYXRpb25zIGZvciB0aGUgdmlydHVhbCBtYWNoaW5lDQogICAgJGFsbFNuYXBzaG90QXNzb2NpYXRpb25zID0gJE1zdm1fQ29tcHV0ZXJTeXN0ZW0uR2V0UmVsYXRpb25zaGlwcygiTXN2bV9TbmFwc2hvdE9mVmlydHVhbFN5c3RlbSIpDQoNCiAgICAjIEVudW1lcmF0ZSBhY3Jvc3MgYWxsIG9mIHRoZSBpbnN0YW5jZXMgYW5kIGFkZCBhbGwgcmVjb3Zlcnkgc25hcHNob3RzIHRvIGFuIGFycmF5DQogICAgJHZpcnR1YWxTeXN0ZW1TbmFwc2hvdHMgPSBAKCkNCiAgICAkZW51bSA9ICRhbGxTbmFwc2hvdEFzc29jaWF0aW9ucy5HZXRFbnVtZXJhdG9yKCkNCiAgICAkZW51bS5SZXNldCgpDQogICAgd2hpbGUoJGVudW0uTW92ZU5leHQoKSkNCiAgICB7DQogICAgICAgIGlmICgoW1dNSV0gJGVudW0uQ3VycmVudC5EZXBlbmRlbnQpLlZpcnR1YWxTeXN0ZW1UeXBlIC1lcSAiTWljcm9zb2Z0Okh5cGVyLVY6U25hcHNob3Q6UmVjb3ZlcnkiKQ0KICAgICAgICB7DQogICAgICAgICAgICAkdmlydHVhbFN5c3RlbVNuYXBzaG90cyArPSAoW1dNSV0gJGVudW0uQ3VycmVudC5EZXBlbmRlbnQpDQogICAgICAgIH0NCiAgICB9DQoNCiAgICAjIFJldHVybiB0aGUgYXJyYXkgb2YgcmVjb3Zlcnkgc25hcHNob3RzDQogICAgJHZpcnR1YWxTeXN0ZW1TbmFwc2hvdHMNCn0NCg0KZnVuY3Rpb24gR2V0LVZtUmVmZXJlbmNlUG9pbnRzDQp7DQogICAgUGFyYW0oDQogICAgICBbUGFyYW1ldGVyKE1hbmRhdG9yeT0kVHJ1ZSldDQogICAgICBbc3RyaW5nXSRWbU5hbWUgPSBbU3RyaW5nXTo6RW1wdHkNCiAgICApDQoNCiAgICAjIFJldHJpZXZlIGFuIGluc3RhbmNlIG9mIHRoZSB2aXJ0dWFsIG1hY2hpbmUgY29tcHV0ZXIgc3lzdGVtIHRoYXQgY29udGFpbnMgcmVmZXJlbmNlIHBvaW50cw0KICAgICRNc3ZtX0NvbXB1dGVyU3lzdGVtID0gR2V0LVdtaU9iamVjdCAtTmFtZXNwYWNlIHJvb3RcdmlydHVhbGl6YXRpb25cdjIgLUNsYXNzIE1zdm1fQ29tcHV0ZXJTeXN0ZW0gLUZpbHRlciAiRWxlbWVudE5hbWU9JyRWbU5hbWUnIg0KDQogICAgIyBSZXRyaWV2ZSBhbGwgcmVmcmVuY2UgYXNzb2NpYXRpb25zIG9mIHRoZSB2aXJ0dWFsIG1hY2hpbmUNCiAgICAkYWxscmVmUG9pbnRzID0gJE1zdm1fQ29tcHV0ZXJTeXN0ZW0uR2V0UmVsYXRpb25zaGlwcygiTXN2bV9SZWZlcmVuY2VQb2ludE9mVmlydHVhbFN5c3RlbSIpDQoNCiAgICAjIEVudW1lcmF0ZSBhY3Jvc3MgYWxsIG9mIHRoZSBpbnN0YW5jZXMgYW5kIGFkZCBhbGwgcmVjb3ZlcnkgcG9pbnRzIHRvIGFuIGFycmF5DQogICAgJHZpcnR1YWxTeXN0ZW1SZWZQb2ludCA9IEAoKQ0KICAgICRlbnVtID0gJGFsbHJlZlBvaW50cy5HZXRFbnVtZXJhdG9yKCkNCiAgICAkZW51bS5SZXNldCgpDQogICAgd2hpbGUoJGVudW0uTW92ZU5leHQoKSkNCiAgICB7DQogICAgICAgICR2aXJ0dWFsU3lzdGVtUmVmUG9pbnQgKz0gKFtXTUldICRlbnVtLkN1cnJlbnQuRGVwZW5kZW50KQ0KICAgIH0NCg0KICAgICMgUmV0dXJuIHRoZSBhcnJheSBvZiByZWNvdmVyeSBwb2ludHMNCiAgICAkdmlydHVhbFN5c3RlbVJlZlBvaW50DQp9DQoNCmZ1bmN0aW9uIE5ldy1WbUJhY2t1cENoZWNrcG9pbnQNCnsNCiAgICBQYXJhbSgNCiAgICAgIFtQYXJhbWV0ZXIoTWFuZGF0b3J5PSRUcnVlKV0NCiAgICAgIFtzdHJpbmddJFZtTmFtZSA9IFtTdHJpbmddOjpFbXB0eSwNCiAgICAgIFtWYWxpZGF0ZVNldCgnQXBwbGljYXRpb25Db25zaXN0ZW50JywnQ3Jhc2hDb25zaXN0ZW50JyldDQogICAgICBbc3RyaW5nXSRDb25zaXN0ZW5jeUxldmVsID0gIkFwcGxpY2F0aW9uIENvbnNpc3RlbnQiDQogICAgKQ0KDQogICAgIyBSZXRyaWV2ZSBhbiBpbnN0YW5jZSBvZiB0aGUgdmlydHVhbCBtYWNoaW5lIG1hbmFnZW1lbnQgc2VydmljZQ0KICAgICRNc3ZtX1ZpcnR1YWxTeXN0ZW1NYW5hZ2VtZW50U2VydmljZSA9IEdldC1XbWlPYmplY3QgLU5hbWVzcGFjZSByb290XHZpcnR1YWxpemF0aW9uXHYyIC1DbGFzcyBNc3ZtX1ZpcnR1YWxTeXN0ZW1NYW5hZ2VtZW50U2VydmljZQ0KDQogICAgIyBSZXRyaWV2ZSBhbiBpbnN0YW5jZSBvZiB0aGUgdmlydHVhbCBtYWNoaW5lIHNuYXBzaG90IHNlcnZpY2UNCiAgICAkTXN2bV9WaXJ0dWFsU3lzdGVtU25hcHNob3RTZXJ2aWNlID0gR2V0LVdtaU9iamVjdCAtTmFtZXNwYWNlIHJvb3RcdmlydHVhbGl6YXRpb25cdjIgLUNsYXNzIE1zdm1fVmlydHVhbFN5c3RlbVNuYXBzaG90U2VydmljZQ0KDQogICAgIyBSZXRyaWV2ZSBhbiBpbnN0YW5jZSBvZiB0aGUgdmlydHVhbCBtYWNoaW5lIGNvbXB1dGVyIHN5c3RlbSB0aGF0IHdpbGwgYmUgc25hcHNob3R0ZWQNCiAgICAkTXN2bV9Db21wdXRlclN5c3RlbSA9IEdldC1XbWlPYmplY3QgLU5hbWVzcGFjZSByb290XHZpcnR1YWxpemF0aW9uXHYyIC1DbGFzcyBNc3ZtX0NvbXB1dGVyU3lzdGVtIC1GaWx0ZXIgIkVsZW1lbnROYW1lPSckdm1OYW1lJyINCg0KICAgICMgQ3JlYXRlIGFuIGluc3RhbmNlIG9mIHRoZSBNc3ZtX1ZpcnR1YWxTeXN0ZW1TbmFwc2hvdFNldHRpbmdEYXRhLCB0aGlzIGNsYXNzIHByb3ZpZGVzIG9wdGlvbnMgb24gaG93IHRoZSBjaGVja3BvaW50IHdpbGwgYmUgY3JlYXRlZC4NCiAgICAkTXN2bV9WaXJ0dWFsU3lzdGVtU25hcHNob3RTZXR0aW5nRGF0YSA9IChbV01JQ2xhc3NdIlxcLlxyb290XHZpcnR1YWxpemF0aW9uXHYyOk1zdm1fVmlydHVhbFN5c3RlbVNuYXBzaG90U2V0dGluZ0RhdGEiKS5DcmVhdGVJbnN0YW5jZSgpDQoNCiAgICAjIElkZW50aWZ5IHRoZSBjb25zaXN0ZW5jeSBsZXZlbCBmb3IgdGhlIHNuYXBzaG90Lg0KICAgICMgIDE6ICBBcHBsaWNhdGlvbiBDb25zaXN0ZW50DQogICAgIyAgMjogIENyYXNoIENvbnNpc3RlbnQNCiAgICBzd2l0Y2ggKCRDb25zaXN0ZW5jeUxldmVsKQ0KICAgIHsNCiAgICAgICAgIkFwcGxpY2F0aW9uQ29uc2lzdGVudCIgew0KICAgICAgICAkTXN2bV9WaXJ0dWFsU3lzdGVtU25hcHNob3RTZXR0aW5nRGF0YS5Db25zaXN0ZW5jeUxldmVsID0gMQ0KICAgICAgICB9DQoNCiAgICAgICAgIkNyYXNoQ29uc2lzdGVudCIgew0KICAgICAgICAkTXN2bV9WaXJ0dWFsU3lzdGVtU25hcHNob3RTZXR0aW5nRGF0YS5Db25zaXN0ZW5jeUxldmVsID0gMg0KICAgICAgICB9DQoNCiAgICAgICAgZGVmYXVsdCB7DQogICAgICAgIHRocm93ICJVbmV4cGVjdGVkIENvbnNpc3RhbmN5IExldmVsIFNwZWNpZmllZCINCiAgICAgICAgfQ0KICAgIH0NCg0KICAgICMgU3BlY2lmeSB0aGUgYmVoYXZpb3IgZm9yIGRpc2tzIHRoYXQgY2Fubm90IGJlIHNuYXBzaG90dGVkIChpLmUuIHBhc3MtdGhyb3VnaCwgdmlydHVhbCBmaWJyZSBjaGFubmVsKQ0KICAgICRNc3ZtX1ZpcnR1YWxTeXN0ZW1TbmFwc2hvdFNldHRpbmdEYXRhLklnbm9yZU5vblNuYXBzaG90dGFibGVEaXNrcyA9ICR0cnVlDQoNCiAgICAjIENyZWF0ZSB0aGUgdmlydHVhbCBtYWNoaW5lIHNuYXBzaG90LCB0aGlzIG1ldGhvZCByZXR1cm5zIGEgam9iIG9iamVjdC4NCiAgICAkam9iID0gJE1zdm1fVmlydHVhbFN5c3RlbVNuYXBzaG90U2VydmljZS5DcmVhdGVTbmFwc2hvdCgNCiAgICAgICAgJE1zdm1fQ29tcHV0ZXJTeXN0ZW0sDQogICAgICAgICRNc3ZtX1ZpcnR1YWxTeXN0ZW1TbmFwc2hvdFNldHRpbmdEYXRhLkdldFRleHQoMiksDQogICAgICAgIDMyNzY4KQ0KDQogICAgIyBXYWl0cyBmb3IgdGhlIGpvYiB0byBjb21wbGV0ZSBhbmQgcHJvY2Vzc2VzIGFueSBlcnJvcnMuDQogICAgKCRqb2IgfCBQcm9jZXNzV01JSm9iIC1XbWlDbGFzcyAkTXN2bV9WaXJ0dWFsU3lzdGVtU25hcHNob3RTZXJ2aWNlIC1NZXRob2ROYW1lICJDcmVhdGVTbmFwc2hvdCIpIHwgT3V0LU51bGwNCg0KICAgICMgUmV0cmlldmVzIHRoZSBzbmFwc2hvdCBvYmplY3QgcmVzdWx0aW5nIGZyb20gdGhlIHNuYXBzaG90Lg0KICAgICRzbmFwc2hvdCA9ICgoW1dNSV0kam9iLkpvYikuR2V0UmVsYXRlZCgiTXN2bV9WaXJ0dWFsU3lzdGVtU2V0dGluZ0RhdGEiKSB8ICUgeyRffSkNCg0KICAgICMgUmV0dXJucyB0aGUgc25hcHNob3QgaW5zdGFuY2UNCiAgICByZXR1cm4gJHNuYXBzaG90DQp9DQoNCmZ1bmN0aW9uIFJlbW92ZS1WbVJlZmVyZW5jZVBvaW50DQp7DQogICAgUGFyYW0oDQogICAgICBbUGFyYW1ldGVyKE1hbmRhdG9yeT0kVHJ1ZSldDQogICAgICBbU3lzdGVtLk1hbmFnZW1lbnQuTWFuYWdlbWVudE9iamVjdF0kUmVmZXJlbmNlUG9pbnQgPSAkbnVsbA0KICAgICkNCg0KDQogICAgIyBSZXRyaWV2ZSBhbiBpbnN0YW5jZSBvZiB0aGUgdmlydHVhbCBtYWNoaW5lIHJlZnJlbmNlIHBvaW50IHNlcnZpY2UNCiAgICAkTXN2bV9WaXJ0dWFsU3lzdGVtUmVmZXJlbmNlUG9pbnRTZXJ2aWNlID0gR2V0LVdtaU9iamVjdCAtTmFtZXNwYWNlIHJvb3RcdmlydHVhbGl6YXRpb25cdjIgLUNsYXNzIE1zdm1fVmlydHVhbFN5c3RlbVJlZmVyZW5jZVBvaW50U2VydmljZQ0KDQogICAgIyBSZW1vdmVzIHRoZSB2aXJ0dWFsIG1hY2hpbmUgcmVmZXJlbmNlLCB0aGlzIG1ldGhvZCByZXR1cm5zIGEgam9iIG9iamVjdC4NCiAgICAkam9iID0gJE1zdm1fVmlydHVhbFN5c3RlbVJlZmVyZW5jZVBvaW50U2VydmljZS5EZXN0cm95UmVmZXJlbmNlUG9pbnQoJFJlZmVyZW5jZVBvaW50KQ0KDQogICAgIyBXYWl0cyBmb3IgdGhlIGpvYiB0byBjb21wbGV0ZSBhbmQgcHJvY2Vzc2VzIGFueSBlcnJvcnMuDQogICAgKCRqb2IgfCBQcm9jZXNzV01JSm9iIC1XbWlDbGFzcyAkTXN2bV9WaXJ0dWFsU3lzdGVtUmVmZXJlbmNlUG9pbnRTZXJ2aWNlIC1NZXRob2ROYW1lICJEZXN0cm95UmVmZXJlbmNlUG9pbnQiKSB8IE91dC1OdWxsDQp9DQoNCmZ1bmN0aW9uIFJlbW92ZS1WbUJhY2t1cENoZWNrcG9pbnQNCnsNCiAgICBQYXJhbSgNCiAgICAgIFtQYXJhbWV0ZXIoTWFuZGF0b3J5PSRUcnVlKV0NCiAgICAgIFtzdHJpbmddJFZtTmFtZSA9IFtTdHJpbmddOjpFbXB0eSwNCiAgICAgIFtTeXN0ZW0uTWFuYWdlbWVudC5NYW5hZ2VtZW50T2JqZWN0XSRCYWNrdXBDaGVja3BvaW50ID0gJG51bGwNCiAgICApDQoJIyBSZXRyaWV2ZSBhbiBpbnN0YW5jZSBvZiB0aGUgdmlydHVhbCBtYWNoaW5lIG1hbmFnZW1lbnQgc2VydmljZQ0KICAgICRNc3ZtX1ZpcnR1YWxTeXN0ZW1NYW5hZ2VtZW50U2VydmljZSA9IEdldC1XbWlPYmplY3QgLU5hbWVzcGFjZSByb290XHZpcnR1YWxpemF0aW9uXHYyIC1DbGFzcyBNc3ZtX1ZpcnR1YWxTeXN0ZW1NYW5hZ2VtZW50U2VydmljZQ0KDQogICAgIyBSZXRyaWV2ZSBhbiBpbnN0YW5jZSBvZiB0aGUgdmlydHVhbCBtYWNoaW5lIHNuYXBzaG90IHNlcnZpY2UNCiAgICAkTXN2bV9WaXJ0dWFsU3lzdGVtU25hcHNob3RTZXJ2aWNlID0gR2V0LVdtaU9iamVjdCAtTmFtZXNwYWNlIHJvb3RcdmlydHVhbGl6YXRpb25cdjIgLUNsYXNzIE1zdm1fVmlydHVhbFN5c3RlbVNuYXBzaG90U2VydmljZQ0KDQogICAgIyBSZXRyaWV2ZSBhbiBpbnN0YW5jZSBvZiB0aGUgdmlydHVhbCBtYWNoaW5lIGNvbXB1dGVyIHN5c3RlbSB0aGF0IHdpbGwgYmUgc25hcHNob3R0ZWQNCiAgICAkTXN2bV9Db21wdXRlclN5c3RlbSA9IEdldC1XbWlPYmplY3QgLU5hbWVzcGFjZSByb290XHZpcnR1YWxpemF0aW9uXHYyIC1DbGFzcyBNc3ZtX0NvbXB1dGVyU3lzdGVtIC1GaWx0ZXIgIkVsZW1lbnROYW1lPSckdm1OYW1lJyINCg0KCSMgQ3JlYXRlIHRoZSB2aXJ0dWFsIG1hY2hpbmUgc25hcHNob3QsIHRoaXMgbWV0aG9kIHJldHVybnMgYSBqb2Igb2JqZWN0Lg0KICAgICRqb2IgPSAkTXN2bV9WaXJ0dWFsU3lzdGVtU25hcHNob3RTZXJ2aWNlLkRlc3Ryb3lTbmFwc2hvdCgkQmFja3VwQ2hlY2twb2ludCkNCg0KICAgICMgV2FpdHMgZm9yIHRoZSBqb2IgdG8gY29tcGxldGUgYW5kIHByb2Nlc3NlcyBhbnkgZXJyb3JzLg0KICAgICgkam9iIHwgUHJvY2Vzc1dNSUpvYiAtV21pQ2xhc3MgJE1zdm1fVmlydHVhbFN5c3RlbVNuYXBzaG90U2VydmljZSAtTWV0aG9kTmFtZSAiRGVzdHJveVNuYXBzaG90IikgfCBPdXQtTnVsbA0KfQ0KZnVuY3Rpb24gUmVzdG9yZUZ1bGxCYWNrdXANCnsNCiAgICBQYXJhbSgNCiAgICAgIFtQYXJhbWV0ZXIoTWFuZGF0b3J5PSRUcnVlKV0NCiAgICAgIFtzdHJpbmddJFZtTmFtZSA9IFtTdHJpbmddOjpFbXB0eSwNCiAgICAgIFtzdHJpbmddJGZ1bGxCYWNrdXBQYXRoID0gW1N0cmluZ106OkVtcHR5LA0KCSAgW3N0cmluZ10kcmVzdG9yZVBhdGggPSBbU3RyaW5nXTo6RW1wdHkNCiAgICApDQoNCgkjIEZpbmQgYSB2aXJ0dWFsIG1hY2hpbmUgY29uZmlndXJhdGlvbiBmaWxlDQoJJHZtQ29uZmlnRmlsZSA9IEdldC1DaGlsZEl0ZW0gLVBhdGggJGZ1bGxCYWNrdXBQYXRoIC1SZWN1cnNlIC1JbmNsdWRlICIqLnZtY3giDQoNCgkjIEltcG9ydCBhIFZNIGZyb20gYmFja3VwDQoJJGltcG9ydGVkID0gSW1wb3J0LVZNIC1QYXRoICR2bUNvbmZpZ0ZpbGUuRnVsbE5hbWUgLUdlbmVyYXRlTmV3SWQgLUNvcHkgLVZpcnR1YWxNYWNoaW5lUGF0aCAkcmVzdG9yZVBhdGggLVZoZERlc3RpbmF0aW9uUGF0aCAiJHJlc3RvcmVQYXRoXFZpcnR1YWwgSGFyZCBEaXNrcyINCn0NCmZ1bmN0aW9uIFJlc3RvcmVEaWZmZXJlbnRpYWxCYWNrdXANCnsNCglQYXJhbSgNCgkJICBbUGFyYW1ldGVyKE1hbmRhdG9yeT0kVHJ1ZSldDQoJCSAgW3N0cmluZ10kVm1OYW1lID0gW1N0cmluZ106OkVtcHR5LA0KCQkgIFtzdHJpbmddJGZ1bGxCYWNrdXBQYXRoID0gW1N0cmluZ106OkVtcHR5LA0KCQkgIFtzdHJpbmddJGRpZmZCYWNrdXBQYXRoID0gW1N0cmluZ106OkVtcHR5LA0KCQkgIFtzdHJpbmddJHJlc3RvcmVQYXRoID0gW1N0cmluZ106OkVtcHR5DQoJCSkNCg0KCSMgQ29weSB2aXJ0dWFsIGRpc2tzIGZyb20gdGhlIGZ1bGwgYmFja3VwIGluIGFkdmFuY2UgdG8gbWFrZSBzdXJlIGRpZmYgY291bGQgbWVyZ2UgcHJvcGVybHkgZHVyaW5nIGltcG9ydA0KCSRkaXNrc1BhdGhTb3VyY2UgPSBKb2luLVBhdGggJGZ1bGxCYWNrdXBQYXRoICJWaXJ0dWFsIEhhcmQgRGlza3MiDQoJJGRpc2tQYXRoRGVzdGluYXRpb24gPSBKb2luLVBhdGggJHJlc3RvcmVQYXRoICJWaXJ0dWFsIEhhcmQgRGlza3MiDQoJQ29weS1JdGVtICRkaXNrc1BhdGhTb3VyY2UgJGRpc2tQYXRoRGVzdGluYXRpb24gLVJlY3Vyc2UgLUZvcmNlIC1FcnJvckFjdGlvbiBTaWxlbnRseUNvbnRpbnVlDQoNCgkjIEZpbmQgYSB2aXJ0dWFsIG1hY2hpbmUgY29uZmlndXJhdGlvbiBmaWxlDQoJJHZtQ29uZmlnRmlsZSA9IEdldC1DaGlsZEl0ZW0gLVBhdGggJGRpZmZCYWNrdXBQYXRoIC1SZWN1cnNlIC1JbmNsdWRlICIqLnZtY3giDQoNCgkjIEltcG9ydCBhIFZNIGZyb20gYmFja3VwDQoJJGltcG9ydGVkID0gSW1wb3J0LVZNIC1QYXRoICR2bUNvbmZpZ0ZpbGUuRnVsbE5hbWUgLUdlbmVyYXRlTmV3SWQgLUNvcHkgLVZpcnR1YWxNYWNoaW5lUGF0aCAkcmVzdG9yZVBhdGggLVZoZERlc3RpbmF0aW9uUGF0aCAiJHJlc3RvcmVQYXRoXFZpcnR1YWwgSGFyZCBEaXNrcyINCn0=";
        //事务处理 全部成功或全部失败
        static bool Full_back_up(PowerShell ps, string name, string out_path)
        {
            try
            {
                ps.Commands.Clear();
                ps.AddCommand("New-VmBackupCheckpoint")
                    .AddParameter("VmName", name)
                    .AddParameter("ConsistencyLevel", "CrashConsistent");

                Collection<PSObject> checkpoints = ps.Invoke();
                if (checkpoints.Count == 0)
                {
                    return false;
                }
                ps.Commands.Clear();

                ps.AddCommand("Export-VMBackupCheckpoint")
                    .AddParameter("VmName", name)
                    .AddParameter("DestinationPath", out_path)
                    .AddParameter("BackupCheckpoint", checkpoints[0]);
                ps.Invoke();

                ps.Commands.Clear();
                ps.AddCommand("Convert-VmBackupCheckpoint")
                    .AddParameter("BackupCheckpoint", checkpoints[0]);

                Collection<PSObject> end_ = ps.Invoke();
                if (end_.Count == 0)
                {
                    //Todo 删除文件
                    RemoveCheckPoint(ps, name, checkpoints[0]);
                    return false;
                }
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
        }
        static bool Incremental_back_up(PowerShell ps, string name, string out_path)
        {
            try
            {
                ps.Commands.Clear();
                ps.AddCommand("New-VmBackupCheckpoint")
                    .AddParameter("VmName", name)
                    .AddParameter("ConsistencyLevel", "CrashConsistent");

                Collection<PSObject> checkpoints = ps.Invoke();
                if (checkpoints.Count == 0)
                {
                    return false;
                }
                ps.Commands.Clear();

                ps.AddCommand("Get-VmReferencePoints")
                    .AddParameter("VmName", name);
                Collection<PSObject> referencePoints = ps.Invoke();
                if (referencePoints.Count == 0)
                {
                    RemoveCheckPoint(ps, name, checkpoints[0]);
                    return false;
                }
                ps.Commands.Clear();

                ps.AddCommand("Export-VMBackupCheckpoint")
                    .AddParameter("VmName", name)
                    .AddParameter("DestinationPath", out_path)
                    .AddParameter("BackupCheckpoint", checkpoints[0])
                    .AddParameter("ReferencePoint", referencePoints[0]);

                ps.Invoke();
                ps.Commands.Clear();

                //根据实际决定是否删除
                ps.AddCommand("Remove-VmReferencePoint")
                    .AddParameter("ReferencePoint", referencePoints[0]);

                ps.Invoke();
                ps.Commands.Clear();

                ps.AddCommand("Convert-VmBackupCheckpoint")
                    .AddParameter("BackupCheckpoint", checkpoints[0]);

                Collection<PSObject> end_ = ps.Invoke();
                if (end_.Count == 0)
                {
                    //Todo 删除文件
                    RemoveCheckPoint(ps, name, checkpoints[0]);
                    return false;
                }
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
        }

        //删除全部检查点
        static void RemoveAllCheckpoints(PowerShell ps, string name)
        {
            ps.Commands.Clear();
            ps.AddCommand("Get-VmBackupCheckpoints")
                .AddParameter("VmName", name);
            Collection<PSObject> checkpoints = ps.Invoke();
            if (checkpoints.Count == 0)
            {
                return;
            }
            foreach(PSObject checkpoint in checkpoints)
            {
                RemoveCheckPoint(ps, name, checkpoint);
            }
        }
        //删除全部应用点
        static void RemoveAllReferencePoints(PowerShell ps, string name)
        {
            ps.Commands.Clear();
            ps.AddCommand("Get-VmReferencePoints")
                .AddParameter("VmName", name);
            Collection<PSObject> referencePoints = ps.Invoke();
            if (referencePoints.Count == 0)
            {
                return;
            }
            foreach (PSObject referencePoint in referencePoints)
            {
                RemoveReferencePoint(ps, name, referencePoint);
            }
        }
        //删除检查点
        static void RemoveReferencePoint(PowerShell ps, string name, PSObject referencePoint)
        {
            try
            {
                if (referencePoint == null)
                {
                    return;
                }
                ps.Commands.Clear();

                ps.AddCommand("Remove-VmBackupCheckpoint")
                   .AddParameter("VmName", name)
                   .AddParameter("BackupCheckpoint", referencePoint);

                ps.Invoke();
                ps.Commands.Clear();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //删除检查点
        static void RemoveCheckPoint(PowerShell ps, string name, PSObject checkpoint)
        {
            try
            {
                if(checkpoint == null)
                {
                    return;
                }
                ps.Commands.Clear();

                ps.AddCommand("Remove-VmBackupCheckpoint")
                   .AddParameter("VmName", name)
                   .AddParameter("BackupCheckpoint", checkpoint);

                ps.Invoke();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
        //全备份恢复
        static void Restore_full_backup(PowerShell ps, string name, string fullBackupPath, string restorePath)
        {
            try
            {
                ps.Commands.Clear();
                ps.AddCommand("RestoreFullBackup")
                   .AddParameter("VmName", name)
                   .AddParameter("fullBackupPath", fullBackupPath)
                   .AddParameter("restorePath", restorePath);

                ps.Invoke();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        //增量备份恢复
        static void RestoreDifferentialBackup(PowerShell ps, string name, string fullBackupPath, string diffBackupPath, string restorePath)
        {
            try
            {
                ps.Commands.Clear();
                ps.AddCommand("RestoreDifferentialBackup")
                   .AddParameter("VmName", name)
                   .AddParameter("fullBackupPath", fullBackupPath)
                   .AddParameter("diffBackupPath", diffBackupPath)
                   .AddParameter("restorePath", restorePath);

                ps.Invoke();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        static void Main(string[] args)
        {
            using (Runspace runspace = RunspaceFactory.CreateRunspace())
            {
                string name = "XP";
                runspace.Open();
                PowerShell ps = PowerShell.Create();
                ps.Runspace = runspace;
                byte[] bpath = Convert.FromBase64String(base64_script);
                string script = System.Text.ASCIIEncoding.Default.GetString(bpath);
                ps.AddScript(script, false);
                ps.Invoke();

                //RemoveAllCheckpoints(ps, name);
                //RemoveAllReferencePoints(ps, name);
                //Full_back_up(ps, name, "C:\\out\\XP");
                //Incremental_back_up(ps, name, "C:\\out\\inc");
                //Restore_full_backup(ps,name, "C:\\out\\XP", "C:\\Hyper-V\\XP");
                RestoreDifferentialBackup(ps, name, "C:\\out\\XP", "C:\\out\\inc", "C:\\Hyper-V\\XP");

                runspace.Close();
            }
        }
    }
}
